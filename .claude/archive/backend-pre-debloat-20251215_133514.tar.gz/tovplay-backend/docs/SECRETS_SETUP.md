# TovPlay Secrets and Configuration Setup Guide

This guide explains how to securely configure environment-specific secrets for the TovPlay application.

## 🔒 Security Overview

TovPlay uses environment-specific configuration files with secure secret management:

- **Development**: Local `.env` file (not committed)
- **Staging/Production**: GitHub Secrets + CI/CD deployment
- **All environments**: Validated configuration with security checks

## 📁 Configuration Files

### Environment Templates

- `.env.example` - Template showing all required variables
- `.env.development` - Local development configuration
- `.env.staging` - Staging environment template (uses GitHub secrets)
- `.env.production` - Production environment template (uses GitHub secrets)

### Scripts and Tools

- `scripts/secrets/manage_secrets.py` - Secrets management utility
- `scripts/secrets/validate_config.py` - Configuration validator
- `src/config/secure_config.py` - Secure configuration loader

## 🚀 Quick Setup

### 1. Local Development

```bash
# Copy the example file
cp .env.example .env

# Edit .env with your local values
# IMPORTANT: Never commit the .env file!

# Generate secure keys
python -c "import secrets; print(f'SECRET_KEY={secrets.token_urlsafe(64)}')"
python -c "import secrets; print(f'JWT_SECRET_KEY={secrets.token_urlsafe(64)}')"

# Validate configuration
python scripts/secrets/validate_config.py -e development
```

### 2. GitHub Repository Secrets

Go to your repository: `Settings > Secrets and variables > Actions`

Add these repository secrets:

#### Staging Environment
```
STAGING_SECRET_KEY=<64-char-random-string>
STAGING_JWT_SECRET_KEY=<64-char-random-string>
STAGING_DB_USER=your_staging_db_user
STAGING_DB_PASSWORD=your_staging_db_password
STAGING_DB_HOST=your_staging_db_host
STAGING_DATABASE_URL=postgresql://user:pass@host:5432/TovPlay_Staging
STAGING_EMAIL_SENDER=staging@tovtech.org
STAGING_EMAIL_PASSWORD=your_staging_email_password
STAGING_SMTP_SERVER=your_smtp_server
STAGING_WEBSITE_URL=https://staging.tovtech.org
STAGING_API_KEY=<32-char-random-string>
STAGING_ALLOWED_ORIGINS=https://staging.tovtech.org
```

#### Production Environment
```
PRODUCTION_SECRET_KEY=<64-char-random-string>
PRODUCTION_JWT_SECRET_KEY=<64-char-random-string>
PRODUCTION_DB_USER=your_production_db_user
PRODUCTION_DB_PASSWORD=your_production_db_password
PRODUCTION_DB_HOST=your_production_db_host
PRODUCTION_DATABASE_URL=postgresql://user:pass@host:5432/TovPlay
PRODUCTION_EMAIL_SENDER=noreply@tovtech.org
PRODUCTION_EMAIL_PASSWORD=your_production_email_password
PRODUCTION_SMTP_SERVER=your_smtp_server
PRODUCTION_WEBSITE_URL=https://tovtech.org
PRODUCTION_API_KEY=<32-char-random-string>
PRODUCTION_ALLOWED_ORIGINS=https://tovtech.org
```

#### Deployment Secrets
```
SSH_PRIVATE_KEY=<your-ssh-private-key>
SSH_HOST=<your-server-host>
SSH_USERNAME=<your-server-username>
SSH_PASSWORD=<your-server-password>
```

### 3. Generate Secure Keys

Use the secrets management script:

```bash
# Generate all templates with secure keys
python scripts/secrets/manage_secrets.py --generate-template development
python scripts/secrets/manage_secrets.py --generate-template staging
python scripts/secrets/manage_secrets.py --generate-template production

# Get GitHub secrets template
python scripts/secrets/manage_secrets.py --github-secrets
```

## 🛡️ Security Best Practices

### Key Requirements

- **Flask SECRET_KEY**: Minimum 64 characters, cryptographically random
- **JWT_SECRET_KEY**: Minimum 64 characters, different from Flask secret
- **Database passwords**: Minimum 32 characters, alphanumeric + symbols
- **API keys**: Minimum 32 characters, URL-safe random strings

### Environment-Specific Rules

#### Development
- Can use weaker secrets for testing
- Debug mode allowed
- Local database connections

#### Staging  
- Production-like secrets required
- Debug mode enabled for troubleshooting
- Staging-specific database and services

#### Production
- Maximum security requirements
- Debug mode disabled
- HTTPS-only connections
- Strict CORS policies

### Secret Rotation

Rotate secrets regularly:

```bash
# Generate new secrets
NEW_SECRET=$(python -c "import secrets; print(secrets.token_urlsafe(64))")
NEW_JWT_SECRET=$(python -c "import secrets; print(secrets.token_urlsafe(64))")

# Update GitHub secrets
# Update environment files
# Deploy with new secrets
```

## 🔧 Configuration Validation

### Validate Current Configuration

```bash
# Validate all environments
python scripts/secrets/validate_config.py

# Validate specific environment
python scripts/secrets/validate_config.py -e production

# Generate security report
python scripts/secrets/validate_config.py --security-report

# JSON output for automation
python scripts/secrets/validate_config.py --json-output
```

### Common Validation Errors

| Error | Solution |
|-------|----------|
| "SECRET_KEY too weak" | Generate a new 64-character key |
| "Missing required variable" | Add the variable to your .env file |
| "Placeholder value detected" | Replace with actual secret values |
| "Debug mode enabled in production" | Set `FLASK_ENV=production` |
| "Same secret for Flask and JWT" | Use different secrets |

## 📊 Configuration Management

### View Configuration Status

```bash
# Get comprehensive validation report
python scripts/secrets/manage_secrets.py --validate

# Get configuration summary
python scripts/secrets/manage_secrets.py --summary
```

### Environment File Security

The `.gitignore` file prevents accidental commits:

```gitignore
# Environment files
.env
.env.*
!.env.example

# Secrets and security
*.pem
*.key
*.crt
secrets/
*.encrypted
```

## 🚨 Security Incident Response

### If Secrets Are Compromised

1. **Immediate Actions**:
   ```bash
   # Generate new secrets immediately
   python scripts/secrets/manage_secrets.py --generate-template production
   
   # Update GitHub secrets
   # Deploy emergency update
   ```

2. **Investigation**:
   - Check git history for committed secrets
   - Review access logs
   - Identify scope of exposure

3. **Recovery**:
   - Rotate all potentially compromised secrets
   - Update database passwords
   - Regenerate API keys
   - Notify users if necessary

### If .env Files Are Committed

1. **Remove from Git History**:
   ```bash
   # Remove file from history (dangerous!)
   git filter-branch --index-filter 'git rm --cached --ignore-unmatch .env' HEAD
   
   # Force push (coordinate with team!)
   git push --force-with-lease
   ```

2. **Rotate All Secrets**:
   - Generate new secrets for all environments
   - Update GitHub repository secrets
   - Deploy updates immediately

## 🔄 CI/CD Integration

The GitHub Actions workflow automatically:

- Validates configuration before deployment
- Uses environment-specific secrets
- Runs security checks
- Deploys with proper environment variables

### Deployment Environment Variables

The CI/CD pipeline sets these automatically:

```yaml
env:
  FLASK_ENV: ${{ matrix.environment }}
  SECRET_KEY: ${{ secrets.STAGING_SECRET_KEY }}
  JWT_SECRET_KEY: ${{ secrets.STAGING_JWT_SECRET_KEY }}
  # ... other environment-specific secrets
```

## 📞 Support

For security-related questions or incidents:

1. **Configuration Issues**: Use the validation scripts
2. **Secret Rotation**: Follow the rotation guide above
3. **Security Incidents**: Follow the incident response plan
4. **General Questions**: Check this documentation first

## 📚 Additional Resources

- [OWASP Configuration Management](https://owasp.org/www-community/Application_Security_Configuration)
- [Flask Security Best Practices](https://flask.palletsprojects.com/en/2.0.x/security/)
- [GitHub Secrets Documentation](https://docs.github.com/en/actions/security-guides/encrypted-secrets)