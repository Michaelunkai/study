# TovPlay Database Migration Guide

## Overview

TovPlay uses a custom database migration system to manage database schema changes in a version-controlled, repeatable manner. This system supports both up and down migrations with rollback capabilities.

## Migration System Features

- **Version Tracking**: Each migration has a unique version number
- **Up/Down Migrations**: Support for applying and rolling back changes
- **Rollback Capability**: Safe rollback to any previous version
- **Schema Validation**: Validation of migration files before execution
- **Checksum Verification**: Integrity checking of migration files
- **Transaction Safety**: All migrations run in transactions
- **Comprehensive Logging**: Detailed logging of all migration operations

## Directory Structure

```
scripts/migrations/
├── migration_manager.py       # Main migration manager
├── migrations/               # Migration files directory
│   ├── 001_initial_schema.py
│   ├── 002_add_indexes.py
│   └── ...
└── migration.log            # Migration execution log
```

## Migration File Format

Each migration file must follow this structure:

```python
"""
Migration XXX: Description
Created: YYYY-MM-DD
Description: Detailed description of changes
"""

def up(cursor):
    """
    Apply migration changes.
    
    Args:
        cursor: Database cursor for executing SQL
    """
    cursor.execute("""
        -- Your SQL changes here
    """)

def down(cursor):
    """
    Rollback migration changes.
    
    Args:
        cursor: Database cursor for executing SQL
    """
    cursor.execute("""
        -- Your rollback SQL here
    """)
```

## Usage

### Prerequisites

1. Set DATABASE_URL environment variable:
   ```bash
   export DATABASE_URL="postgresql://user:password@host:port/database"
   ```

2. Ensure Python dependencies are installed:
   ```bash
   pip install psycopg2-binary
   ```

### Basic Commands

#### Check Migration Status
```bash
python scripts/migrations/migration_manager.py status
```

#### Apply All Pending Migrations
```bash
python scripts/migrations/migration_manager.py up
```

#### Apply Migrations to Specific Version
```bash
python scripts/migrations/migration_manager.py up --target 003
```

#### Rollback Last Migration
```bash
python scripts/migrations/migration_manager.py down
```

#### Rollback Multiple Steps
```bash
python scripts/migrations/migration_manager.py down --steps 3
```

#### Rollback to Specific Version
```bash
python scripts/migrations/migration_manager.py down --target 001
```

#### Create New Migration
```bash
python scripts/migrations/migration_manager.py create --name "add_user_preferences"
```

## Environment-Specific Usage

### Development Environment
```bash
# Use development database
export DATABASE_URL="postgresql://dev_user:dev_pass@localhost:5432/tovplay_dev"
python scripts/migrations/migration_manager.py up
```

### Staging Environment
```bash
# Use staging database
export DATABASE_URL="postgresql://staging_user:staging_pass@localhost:5432/tovplay_staging"
python scripts/migrations/migration_manager.py up
```

### Production Environment
```bash
# Use production database (be extra careful!)
export DATABASE_URL="postgresql://prod_user:prod_pass@localhost:5432/tovplay"
python scripts/migrations/migration_manager.py status  # Check first
python scripts/migrations/migration_manager.py up      # Apply if safe
```

## Best Practices

### 1. Always Test Migrations
- Test both up and down migrations in development
- Verify migrations work on sample data
- Test rollback functionality before production deployment

### 2. Write Reversible Migrations
- Always implement both `up()` and `down()` functions
- Ensure down migrations properly reverse all changes
- Consider data loss implications in rollbacks

### 3. Use Transactions Safely
- Each migration runs in its own transaction
- Avoid operations that can't be rolled back (like DROP DATABASE)
- Be cautious with large data modifications

### 4. Schema Change Guidelines
- Prefer additive changes when possible
- Use IF NOT EXISTS for creating objects
- Consider backwards compatibility

### 5. Data Migration Safety
- Always backup data before migrations
- Use small batches for large data changes
- Test with production-like data volumes

## Migration Workflow

### For New Features

1. **Create Migration**:
   ```bash
   python scripts/migrations/migration_manager.py create --name "add_feature_table"
   ```

2. **Implement Changes**:
   - Edit the generated migration file
   - Add SQL for both up and down operations
   - Test thoroughly

3. **Apply Locally**:
   ```bash
   python scripts/migrations/migration_manager.py up
   ```

4. **Test Rollback**:
   ```bash
   python scripts/migrations/migration_manager.py down --steps 1
   python scripts/migrations/migration_manager.py up
   ```

5. **Commit Changes**:
   ```bash
   git add scripts/migrations/migrations/XXX_add_feature_table.py
   git commit -m "feat: Add feature table migration"
   ```

### For Production Deployment

1. **Review Pending Migrations**:
   ```bash
   python scripts/migrations/migration_manager.py status
   ```

2. **Backup Database** (Critical!):
   ```bash
   pg_dump -h host -U user -d database > backup_$(date +%Y%m%d_%H%M%S).sql
   ```

3. **Apply Migrations**:
   ```bash
   python scripts/migrations/migration_manager.py up
   ```

4. **Verify Success**:
   ```bash
   python scripts/migrations/migration_manager.py status
   ```

## Troubleshooting

### Migration Failed
1. Check the migration.log file for detailed error information
2. Verify database connection and permissions
3. Check if the migration SQL is valid
4. Ensure all dependencies are installed

### Rollback Issues
1. Verify the down() function is properly implemented
2. Check if there are foreign key constraints preventing rollback
3. Consider data dependencies that might prevent rollback

### Version Conflicts
1. Check if someone else applied migrations
2. Use `status` command to see current state
3. Resolve conflicts by adjusting migration versions

### Connection Problems
1. Verify DATABASE_URL is correct
2. Check database server is running
3. Verify user permissions
4. Test connection independently

## Integration with Deployment

### CI/CD Pipeline Integration

Add to your deployment script:

```bash
#!/bin/bash
set -e

# Apply database migrations
echo "Applying database migrations..."
python scripts/migrations/migration_manager.py up

# Verify migrations applied successfully
echo "Verifying migration status..."
python scripts/migrations/migration_manager.py status

echo "Migrations completed successfully"
```

### Docker Integration

Add to Dockerfile:

```dockerfile
# Copy migration scripts
COPY scripts/migrations/ /app/scripts/migrations/
COPY docs/MIGRATION_GUIDE.md /app/docs/

# Run migrations in entrypoint
COPY scripts/docker-entrypoint.sh /entrypoint.sh
RUN chmod +x /entrypoint.sh
```

### Health Checks

The migration manager integrates with the health check system:

```python
# Health check includes migration status
GET /health/database
{
    "status": "healthy",
    "migrations": {
        "applied": 5,
        "pending": 0,
        "last_applied": "002_add_indexes"
    }
}
```

## Security Considerations

1. **Environment Variables**: Never commit DATABASE_URL to version control
2. **Permissions**: Use least-privilege database users for migrations
3. **Backups**: Always backup before production migrations
4. **Rollback Plan**: Have a tested rollback plan for critical migrations
5. **Monitoring**: Monitor migration execution and system health

## Monitoring and Logging

- All migration operations are logged to `migration.log`
- Use structured logging for integration with monitoring systems
- Monitor migration execution time and success rates
- Alert on migration failures in production

## Example Migration Scenarios

### Adding a New Table
```python
def up(cursor):
    cursor.execute("""
        CREATE TABLE products (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            price DECIMAL(10,2),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)

def down(cursor):
    cursor.execute("DROP TABLE IF EXISTS products;")
```

### Adding a Column
```python
def up(cursor):
    cursor.execute("""
        ALTER TABLE users 
        ADD COLUMN phone VARCHAR(20);
    """)

def down(cursor):
    cursor.execute("""
        ALTER TABLE users 
        DROP COLUMN IF EXISTS phone;
    """)
```

### Data Migration
```python
def up(cursor):
    # Add new column
    cursor.execute("ALTER TABLE users ADD COLUMN full_name VARCHAR(510);")
    
    # Migrate data
    cursor.execute("""
        UPDATE users 
        SET full_name = CONCAT(first_name, ' ', last_name)
        WHERE first_name IS NOT NULL AND last_name IS NOT NULL;
    """)

def down(cursor):
    cursor.execute("ALTER TABLE users DROP COLUMN IF EXISTS full_name;")
```

This migration system ensures reliable, version-controlled database evolution for the TovPlay application.