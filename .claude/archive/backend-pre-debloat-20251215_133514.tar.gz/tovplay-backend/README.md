# TovPlay Backend

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![CI/CD Status](https://github.com/8GSean/tovplay-backend/actions/workflows/main.yml/badge.svg)](https://github.com/8GSean/tovplay-backend/actions)
[![Docker Hub](https://img.shields.io/badge/Docker-Hub-blue?logo=docker)](https://hub.docker.com/r/tovtech/tovplaybackend)

A modern, scalable backend API for the TovPlay gaming platform built with Flask, PostgreSQL, and Redis.

**🔄 Latest Update (Sept 2024)**: Complete infrastructure overhaul with enhanced security, monitoring, and deployment automation.

## 🚀 Features

- **🎮 Game Management**: Comprehensive game catalog and session management
- **👥 User System**: User registration, authentication, and profile management  
- **📅 Availability Tracking**: Real-time user availability and scheduling
- **🔐 Security**: JWT authentication, input validation, and security scanning
- **📊 Monitoring**: Health checks, metrics, and comprehensive logging
- **🐳 Containerized**: Docker support with multi-stage builds
- **🔄 CI/CD**: Automated testing, building, and Docker Hub deployment

## 🛠️ Tech Stack

- **Framework**: Flask 3.1+
- **Language**: Python 3.13
- **Database**: PostgreSQL with SQLAlchemy 2.0+
- **Cache**: Redis 6+
- **Authentication**: JWT tokens with Flask-JWT-Extended
- **Validation**: Marshmallow 4.0+ schemas
- **Containerization**: Docker with multi-stage builds
- **CI/CD**: GitHub Actions with automated Docker Hub deployment

## 📦 Key Dependencies

- **Flask**: 3.1+ (Web framework)
- **Flask-SQLAlchemy**: 3.1+ (Database ORM)
- **Flask-CORS**: 6.0+ (Cross-origin requests)
- **Flask-Marshmallow**: 1.3+ (Serialization)
- **Gunicorn**: 23.0+ (WSGI server)
- **Redis**: 6.4+ (Caching and sessions)
- **Email-Validator**: 2.2+ (Email validation)

## 📋 Prerequisites

- Python 3.13+
- PostgreSQL 12+
- Redis 6+
- Docker (optional)

## 🔧 Installation

### Local Development

1. **Clone the repository**
   ```bash
   git clone https://github.com/8GSean/tovplay-backend.git
   cd tovplay-backend
   ```

2. **Set up virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements-dev.txt
   ```

4. **Configure environment**
   ```bash
   # cp .env.example .env
   # Edit .env with your configuration
   ```

5. **Run the application**
   ```bash
   # Option 1: Using Flask
   flask run
   
   # Option 2: Using Python directly
   python run.py
   
   # Option 3: Using the one-liner
   run-backend.bat
   ```

### Single External PostgreSQL Usage (Per CLAUDE.md)
This project is configured to use ONLY the central PostgreSQL instance (no local Postgres container) for all environments. Ensure your local `.env` supplies:

```
POSTGRES_HOST=45.148.28.196
POSTGRES_PORT=5432
POSTGRES_DB=TovPlay
POSTGRES_USER=your-username
POSTGRES_PASSWORD=your-password
DATABASE_URL=postgresql://your-username:your-password@45.148.28.196:5432/TovPlay
```

Never hard‑code credentials in compose files; they are loaded from `.env` only. See `.env.example` for the full list.
### Docker Development

1. **Build and run with Docker Compose**
   ```bash
   docker-compose up --build
   ```

2. **The API will be available at**: http://localhost:5001

## 📚 API Documentation

### Health Check
```http
GET /health
```

### User Management
```http
GET    /api/users          # List all users
GET    /api/users/{id}     # Get specific user
POST   /api/users          # Create new user
```

### Game Management
```http
GET    /api/games          # List all games
GET    /api/games/{id}     # Get specific game
POST   /api/games          # Create new game
```

### Availability
```http
GET    /api/availability/request    # Get game requests
POST   /api/availability/request   # Create game request
```

## 🧪 Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=src --cov-report=html

# Run specific test file
pytest tests/test_routes.py
```

## 🔍 Code Quality

```bash
# Format code
black src/
isort src/

# Lint code
flake8 src/

# Type checking
mypy src/
```

## 🛡️ Security

```bash
# Security vulnerability scan
safety check

# Security code analysis
bandit -r src/
```

## 🔄 CI/CD Pipeline

Our GitHub Actions CI/CD automatically handles testing, building, and deployment:

### Production Deployment
When you push to `main`, the pipeline:
1. **Tests**: Runs pytest with Python 3.13 on all API endpoints (/health, /api/users/, /api/games/)
2. **Builds**: Creates optimized Docker images using Python 3.13-slim base
3. **Deploys**: Pushes images to Docker Hub as `tovtech/tovplaybackend:latest` and `tovtech/tovplaybackend:<commit-sha>`
4. **Deploys**: Automatically deploys to the production server

### Staging Deployment
When you push to `develop`, the pipeline:
1. **Builds**: Creates optimized Docker images using Python 3.13-slim base
2. **Deploys**: Pushes images to Docker Hub as `tovtech/tovplaybackend:staging`
3. **Deploys**: Automatically deploys to the staging server

**Team Workflow**: Simply `git push` your changes - no manual Docker commands needed! The CI/CD handles everything automatically using secure GitHub Secrets.

### Docker Hub Access

To manually access our Docker images:

**PowerShell:**
```powershell
docker login
# Username: tovtech
# Password: professor-default-glade-smartly-rogue-reverb7
docker pull tovtech/tovplaybackend:latest
```

**Bash/Linux:**
```bash
echo "professor-default-glade-smartly-rogue-reverb7" | docker login -u tovtech --password-stdin
docker pull tovtech/tovplaybackend:latest
```

**macOS:**
```bash
docker login -u tovtech
# Enter password when prompted: professor-default-glade-smartly-rogue-reverb7
docker pull tovtech/tovplaybackend:latest
```

## 🚀 Deployment

### Production Database Configuration

The application connects to a PostgreSQL database at:
- **Host**: 45.148.28.196
- **Port**: 5432
- **Database**: TovPlay
- **User**: raz@tovtech.org

### Environment Variables

Required environment variables for production:

```bash
SECRET_KEY=your-secret-key
DATABASE_URL=postgresql://user:password@host:port/database
REDIS_URL=redis://localhost:6379/0
FLASK_ENV=production
```

### Docker Deployment

```bash
# Use pre-built image from CI/CD
docker pull tovtech/tovplaybackend:latest

# Run production container
docker run -d \
  --name tovplay-backend \
  -p 5001:5001 \
  -e DATABASE_URL=postgresql://user:pass@host:5432/db \
  -e REDIS_URL=redis://redis:6379/0 \
  tovtech/tovplaybackend:latest
```

## 🏃 Quick Start

### One-liner Local Backend Setup

**PowerShell:**
```powershell
python -m venv venv; .\venv\Scripts\activate; pip install -r requirements-dev.txt; python run.py
```

**Bash/Linux:**
```bash
python -m venv venv && source venv/bin/activate && pip install -r requirements-dev.txt && python run.py
```

**macOS:**
```bash
python3 -m venv venv && source venv/bin/activate && pip install -r requirements-dev.txt && python run.py
```

### Batch Scripts (Windows Only)

Run the backend in one command:
```bash
run-backend.bat
```

Run both backend and frontend:
```bash
# From the parent directory
run-both.bat
```


## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🔗 Links

- **Production API**: https://api.tovplay.com
- **Staging API**: https://api-staging.tovplay.com
- **Docker Hub**: https://hub.docker.com/r/tovtech/tovplaybackend
- **CI/CD Status**: https://github.com/8GSean/tovplay-backend/actions

## 📞 Support

For support and questions, please open an issue in this repository.

---

**Built with ❤️ by the TovPlay Team**

*Last CI/CD test: September 2, 2025*
# CI/CD Test Tue, Sep  2, 2025  6:51:01 PM

__________________________________________________________________________________________________

# ONE LINERS TO FORCE PUSH TO STAGING/PRODUCTION ENVIRONMENTS

## BACKEND ONLY

### PowerShell:


# Push BACKEND to STAGING main branch
cd F:/tovplay/tovplay-backend; git checkout main 2>$null; git pull origin main; git commit --allow-empty -m "Force deploy - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin main --force; Write-Host "Backend FORCE PUSHED to STAGING main branch 92.113.144.59"

# Push BACKEND to PRODUCTION develop branch
cd F:/tovplay/tovplay-backend; git checkout develop 2>$null; git pull origin develop; git commit --allow-empty -m "Force deploy - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin develop --force; git checkout main 2>$null; Write-Host "Backend FORCE PUSHED to PRODUCTION develop branch 193.181.213.220"

# Push BACKEND to both STAGING and PRODUCTION
Write-Host "Step 1 Pushing Backend to STAGING main branch"; cd F:/tovplay/tovplay-backend; git checkout main 2>$null; git pull origin main; git commit --allow-empty -m "Force deploy STAGING - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin main --force; Write-Host "Step 2 Pushing Backend to PRODUCTION develop branch"; git checkout develop 2>$null; git pull origin develop; git commit --allow-empty -m "Force deploy PRODUCTION - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin develop --force; git checkout main 2>$null; Write-Host "Backend FORCE PUSHED to STAGING 92.113.144.59 and PRODUCTION 193.181.213.220"


### Linux:


# Push BACKEND to STAGING main branch
cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && echo "Backend FORCE PUSHED to STAGING main branch 92.113.144.59"

# Push BACKEND to PRODUCTION develop branch
cd /f/tovplay/tovplay-backend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && git checkout main 2>/dev/null && echo "Backend FORCE PUSHED to PRODUCTION develop branch 193.181.213.220"

# Push BACKEND to both STAGING and PRODUCTION
echo "Step 1 Pushing Backend to STAGING main branch" && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy STAGING - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && echo "Step 2 Pushing Backend to PRODUCTION develop branch" && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy PRODUCTION - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && git checkout main 2>/dev/null && echo "Backend FORCE PUSHED to STAGING 92.113.144.59 and PRODUCTION 193.181.213.220"


### macOS:


# Push BACKEND to STAGING main branch
cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && echo "Backend FORCE PUSHED to STAGING main branch 92.113.144.59"

# Push BACKEND to PRODUCTION develop branch
cd /f/tovplay/tovplay-backend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && git checkout main 2>/dev/null && echo "Backend FORCE PUSHED to PRODUCTION develop branch 193.181.213.220"

# Push BACKEND to both STAGING and PRODUCTION
echo "Step 1 Pushing Backend to STAGING main branch" && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy STAGING - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && echo "Step 2 Pushing Backend to PRODUCTION develop branch" && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy PRODUCTION - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && git checkout main 2>/dev/null && echo "Backend FORCE PUSHED to STAGING 92.113.144.59 and PRODUCTION 193.181.213.220"




___
## BOTH (BACKEND + FRONTEND)

### PowerShell:


# Push BOTH to STAGING main branch
cd F:/tovplay/tovplay-backend; git checkout main 2>$null; git pull origin main; git commit --allow-empty -m "Force deploy - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin main --force; cd F:/tovplay/tovplay-frontend; git checkout main 2>$null; git pull origin main; git commit --allow-empty -m "Force deploy - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin main --force; cd F:/tovplay/tovplay-backend; git checkout main 2>$null; Write-Host "Both repos FORCE PUSHED to STAGING main branch 92.113.144.59"

# Push BOTH to PRODUCTION develop branch
cd F:/tovplay/tovplay-backend; git checkout develop 2>$null; git pull origin develop; git commit --allow-empty -m "Force deploy - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin develop --force; cd F:/tovplay/tovplay-frontend; git checkout develop 2>$null; git pull origin develop; git commit --allow-empty -m "Force deploy - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin develop --force; cd F:/tovplay/tovplay-backend; git checkout main 2>$null; Write-Host "Both repos FORCE PUSHED to PRODUCTION develop branch 193.181.213.220"

# Push BOTH to STAGING and PRODUCTION
Write-Host "Step 1 Pushing to STAGING main branch"; cd F:/tovplay/tovplay-backend; git checkout main 2>$null; git pull origin main; git commit --allow-empty -m "Force deploy STAGING - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin main --force; cd F:/tovplay/tovplay-frontend; git checkout main 2>$null; git pull origin main; git commit --allow-empty -m "Force deploy STAGING - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin main --force; Write-Host "Step 2 Pushing to PRODUCTION develop branch"; cd F:/tovplay/tovplay-backend; git checkout develop 2>$null; git pull origin develop; git commit --allow-empty -m "Force deploy PRODUCTION - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin develop --force; cd F:/tovplay/tovplay-frontend; git checkout develop 2>$null; git pull origin develop; git commit --allow-empty -m "Force deploy PRODUCTION - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"; git push origin develop --force; cd F:/tovplay/tovplay-backend; git checkout main 2>$null; Write-Host "Both repos FORCE PUSHED to STAGING 92.113.144.59 and PRODUCTION 193.181.213.220"


### Linux:


# Push BOTH to STAGING main branch
cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && cd /f/tovplay/tovplay-frontend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && echo "Both repos FORCE PUSHED to STAGING main branch 92.113.144.59"

# Push BOTH to PRODUCTION develop branch
cd /f/tovplay/tovplay-backend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && cd /f/tovplay/tovplay-frontend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && echo "Both repos FORCE PUSHED to PRODUCTION develop branch 193.181.213.220"

# Push BOTH to STAGING and PRODUCTION
echo "Step 1 Pushing to STAGING main branch" && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy STAGING - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && cd /f/tovplay/tovplay-frontend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy STAGING - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && echo "Step 2 Pushing to PRODUCTION develop branch" && cd /f/tovplay/tovplay-backend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy PRODUCTION - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && cd /f/tovplay/tovplay-frontend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy PRODUCTION - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && echo "Both repos FORCE PUSHED to STAGING 92.113.144.59 and PRODUCTION 193.181.213.220"

### macOS:

# Push BOTH to STAGING main branch
cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && cd /f/tovplay/tovplay-frontend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && echo "Both repos FORCE PUSHED to STAGING main branch 92.113.144.59"

# Push BOTH to PRODUCTION develop branch
cd /f/tovplay/tovplay-backend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && cd /f/tovplay/tovplay-frontend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && echo "Both repos FORCE PUSHED to PRODUCTION develop branch 193.181.213.220"

# Push BOTH to STAGING and PRODUCTION
echo "Step 1 Pushing to STAGING main branch" && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy STAGING - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && cd /f/tovplay/tovplay-frontend && git checkout main 2>/dev/null && git pull origin main && git commit --allow-empty -m "Force deploy STAGING - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin main --force && echo "Step 2 Pushing to PRODUCTION develop branch" && cd /f/tovplay/tovplay-backend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy PRODUCTION - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && cd /f/tovplay/tovplay-frontend && git checkout develop 2>/dev/null && git pull origin develop && git commit --allow-empty -m "Force deploy PRODUCTION - $(date '+%Y-%m-%d %H:%M:%S')" && git push origin develop --force && cd /f/tovplay/tovplay-backend && git checkout main 2>/dev/null && echo "Both repos FORCE PUSHED to STAGING 92.113.144.59 and PRODUCTION 193.181.213.220"


